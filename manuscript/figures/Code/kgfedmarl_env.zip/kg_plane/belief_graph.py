"""
belief_graph.py
================
KG-FedMARL 恢复知识平面 (Recovery Knowledge Plane)
对应论文 §III-B, §V-A: Algorithm 1 Provenance-Aware Temporal Belief Update

核心数据结构:
    G^B = (T^0, A_t, B_t, P_t, V_t)
实现:
    - 每个动态断言 q 维护 log-odds L_t(q)
    - 来源分组 g(z), 组内影响上限 beta_g  (Eq.39)
    - 时间衰减 lambda_f              (Eq.42)
    - 校准后贡献 u_j(t)              (Eq.37,40)
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import numpy as np


# ---------- 证据与断言 ----------
@dataclass
class Evidence:
    q: str                 # 断言 id
    value: float           # 报告值 (支持度)
    source: str            # 来源 id
    t_event: float         # 源报告事件时间
    t_recv: float          # 可信接收时间 (防重放)
    conf_src: float        # 源自报置信度
    provenance_chain: Tuple[str, ...] = ()  # 来源链, 用于分组


@dataclass
class AssertionState:
    name: str
    L: float = 0.0          # log-odds
    b: float = 0.5           # 信念概率
    prior_L: float = 0.0
    last_update: float = -1.0
    supporting_groups: set = field(default_factory=set)


class BeliefGraph:
    """
    对应 G^B_t. 简化版: 只维护 A_t (断言集) + B_t (信念) + P_t (来源图).
    T^0 (可信本体) 作为只读外部输入.
    """

    def __init__(self, lambda_f: float = 0.95, beta_z: float = 2.0,
                 eps0: float = 1e-6):
        assert 0 < lambda_f < 1
        self.lambda_f = lambda_f
        self.beta_z = beta_z          # 单条证据上限 (Eq.40 clip)
        self.eps0 = eps0
        self.assertions: Dict[str, AssertionState] = {}
        self.source_reliability: Dict[str, float] = {}   # rho_s(t)
        self.group_budget: Dict[str, float] = {}          # beta_g
        self.t: float = 0.0

    # ---------- 公共 API ----------
    def add_assertion(self, name: str, prior: float = 0.5):
        L0 = math.log(prior / (1 - prior + self.eps0) + self.eps0)
        self.assertions[name] = AssertionState(name=name, L=L0, b=prior, prior_L=L0)

    def set_group_budget(self, group: str, beta: float):
        self.group_budget[group] = beta

    def update(self, evidence_batch: List[Evidence], t_now: float):
        """Algorithm 1 主循环."""
        self.t = t_now
        # 1. 按断言 & 来源分组聚合
        groups: Dict[str, List[Evidence]] = {}
        for z in evidence_batch:
            groups.setdefault(z.source, []).append(z)

        effective: Dict[str, float] = {}   # source -> sum u_j
        for src, evs in groups.items():
            rho = self.source_reliability.get(src, 0.5)
            raw = 0.0
            for z in evs:
                cal = self._calibrate(z.conf_src)
                time_f = self._time_factor(z, t_now)
                con_f = self._consistency_factor(z)
                support = self._support(z.value)
                raw += cal * rho * time_f * con_f * support
            # Eq.40: clip 到 [-beta_z, beta_z]
            eff = np.clip(raw, -self.beta_z, self.beta_z)
            effective[src] = eff

        # 2. 来源分组上限 (Eq.38-39)
        group_load: Dict[str, float] = {}
        for src, eff in effective.items():
            g = self._group_of(src)
            group_load[g] = group_load.get(g, 0.0) + abs(eff)
        group_kappa: Dict[str, float] = {}
        for g, load in group_load.items():
            bg = self.group_budget.get(g, self.beta_z)
            kappa = min(1.0, bg / (load + self.eps0))
            group_kappa[g] = kappa

        # 3. 应用更新 (Eq.42)
        for src, eff in effective.items():
            g = self._group_of(src)
            kappa = group_kappa[g]
            for z in groups[src]:
                if z.q not in self.assertions:
                    self.add_assertion(z.q)
                q = self.assertions[z.q]
                # 衰减 + 注入
                q.L = self.lambda_f * q.L + (1 - self.lambda_f) * q.prior_L + kappa * eff
                q.b = 1.0 / (1.0 + math.exp(-q.L))
                q.supporting_groups.add(g)
                q.last_update = t_now

        # 4. 时间衰减: 未收到新证据的活跃断言
        for q in self.assertions.values():
            if q.last_update < t_now - 1e-9 and q.name not in {z.q for z in evidence_batch}:
                q.L = self.lambda_f * q.L + (1 - self.lambda_f) * q.prior_L
                q.b = 1.0 / (1.0 + math.exp(-q.L))

    def query(self, q: str) -> float:
        return self.assertions[q].b if q in self.assertions else 0.5

    # ---------- 内部 ----------
    def _calibrate(self, c: float) -> float:
        # 简化 Platt 校准: 把 [0,1] 压到 [0.05, 0.95]
        return 0.05 + 0.9 * np.clip(c, 0, 1)

    def _time_factor(self, z: Evidence, t_now: float) -> float:
        dt = t_now - z.t_recv
        # 指数衰减, 24 单位时间半衰期
        return math.exp(-dt / 24.0)

    def _consistency_factor(self, z: Evidence) -> float:
        # 与受信任不变量的内部一致性; 这里占位返回 1
        return 1.0

    def _support(self, v: float) -> float:
        # 把连续值映射到有符号支持度
        return float(np.clip(v, -5, 5))

    def _group_of(self, source: str) -> str:
        # 来源名前缀即组, 例如 "rtu_sub1", "rtu_sub2" -> "rtu"
        return source.split("_")[0] if "_" in source else source


# ---------- 来源可靠性更新 (Eq.44-46) ----------
def update_reliability(bg: BeliefGraph, src: str, verified: bool, m: bool = True,
                      lambda_rho: float = 0.9):
    """m=True 表示本轮有独立可验证声明."""
    old = bg.source_reliability.get(src, 0.5)
    if m:
        new = lambda_rho * old + (1.0 if verified else 0.0)
        bg.source_reliability[src] = np.clip(new, 1e-3, 1 - 1e-3)
    # m=False: 仅折扣, 不解释为验证
    else:
        bg.source_reliability[src] = lambda_rho * old


if __name__ == "__main__":
    # 自检: 单断言受 3 个来源、含 1 个被攻陷来源
    bg = BeliefGraph(lambda_f=0.9, beta_z=1.5)
    bg.add_assertion("ctrl_avail_bus5", prior=0.5)
    bg.set_group_budget("rtu", 2.0)
    bg.set_group_budget("ids", 1.0)
    bg.source_reliability = {"rtu_1": 0.8, "rtu_2": 0.7, "ids_1": 0.9}

    ev = [
        Evidence("ctrl_avail_bus5", 1.0, "rtu_1", 0, 0, 0.9, ("rtu_1",)),
        Evidence("ctrl_avail_bus5", 1.0, "rtu_2", 0, 0, 0.8, ("rtu_2",)),
        Evidence("ctrl_avail_bus5", 0.0, "ids_1", 0, 0, 0.85, ("ids_1",)),  # 冲突
    ]
    bg.update(ev, t_now=1.0)
    print(f"b(ctrl_avail_bus5) = {bg.query('ctrl_avail_bus5'):.4f}")
    print("Provenance groups capped:",
          {g: bg.group_budget[g] for g in ["rtu", "ids"]})
