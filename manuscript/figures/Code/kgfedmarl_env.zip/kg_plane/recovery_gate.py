"""
recovery_gate.py
=================
风险感知恢复门 (Risk-Aware Recovery Gate)
对应论文 §V-B: Algorithm 2

输入:
    - 候选动作集合 U_t^0
    - 信念图 BeliefGraph
    - 保守物理状态集 X_hat
    - 每断言风险预算 delta_q, 总预算 delta_bar_B
输出:
    - 可执行动作 a_t^exec
    - 授权记录 R_t^auth
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple
import numpy as np

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from kg_plane.belief_graph import BeliefGraph, Evidence


@dataclass
class ActionCandidate:
    name: str
    prereqs: List[str] = field(default_factory=list)  # 断言名列表 Q(a)


@dataclass
class AuthRecord:
    action: str
    beliefs: Dict[str, float]
    provenance_groups: List[str]
    verifier_version: str = "v1.0"
    passed: bool = False


# ---------- 权威物理校验器 (论文 §III-C 受信组件) ----------
class ConservativeVerifier:
    """
    对候选动作在保守状态集 X_hat 上做不变约束校验.
    生产环境应接 AC 潮流 / MILP / 可达性分析; 这里给接口骨架.
    """
    def __init__(self, x_hat: np.ndarray, verifier_fn: Optional[Callable] = None):
        self.x_hat = x_hat
        self._fn = verifier_fn

    def verify(self, action: ActionCandidate) -> bool:
        if self._fn is not None:
            return bool(self._fn(action, self.x_hat))
        # 默认: 不违反电压/热约束的占位逻辑
        # 真实实现: 跑 ACOPF / 查表 / 规则引擎
        return True


# ---------- Algorithm 2 ----------
class RiskAwareRecoveryGate:
    def __init__(self,
                 belief_graph: BeliefGraph,
                 verifier: ConservativeVerifier,
                 delta_q: Dict[str, float],
                 delta_bar_B: float = 0.1,
                 K_max: int = 8,
                 surrogate_scorer: Optional[Callable] = None):
        self.bg = belief_graph
        self.verifier = verifier
        self.delta_q = delta_q          # 每断言风险预算
        self.delta_bar_B = delta_bar_B  # Eq.49 总预算
        self.K_max = K_max              # 权威校验次数上限
        self._score = surrogate_scorer or self._default_score

    # ---------- 主入口 ----------
    def select(self, candidates: List[ActionCandidate]
               ) -> Tuple[Optional[ActionCandidate], AuthRecord]:
        # Step 1: 语义门 (Eq.48-49)
        U_B: List[ActionCandidate] = []
        for a in candidates:
            if self._semantic_gate(a):
                U_B.append(a)

        if not U_B:
            return None, AuthRecord(action="__none__", beliefs={},
                                    provenance_groups=[], passed=False)

        # Step 2: 学习代理排序 (非权威, Eq.51)
        U_B.sort(key=lambda a: self._score(a), reverse=True)

        # Step 3: 权威校验 (Algorithm 2 line 8-14)
        for k, a in enumerate(U_B):
            if k >= self.K_max:
                break
            if self.verifier.verify(a):
                beliefs = {q: self.bg.query(q) for q in a.prereqs}
                groups = list({g for q in a.prereqs
                               for g in self.bg.assertions.get(q, _empty()).supporting_groups})
                rec = AuthRecord(action=a.name, beliefs=beliefs,
                                 provenance_groups=groups, passed=True)
                return a, rec
        return None, AuthRecord(action="__fallback__", beliefs={},
                                provenance_groups=[], passed=False)

    # ---------- 内部 ----------
    def _semantic_gate(self, a: ActionCandidate) -> bool:
        if not a.prereqs:
            return True
        total_risk = 0.0
        for q in a.prereqs:
            dq = self.delta_q.get(q, 0.05)
            if self.bg.query(q) < 1 - dq:
                return False
            total_risk += dq
        return total_risk <= self.delta_bar_B

    def _default_score(self, a: ActionCandidate) -> float:
        # 占位: 用信念乘积做启发式
        prod = 1.0
        for q in a.prereqs:
            prod *= self.bg.query(q)
        return prod

    def execute_with_fallback(self, candidates, fallback_action: ActionCandidate
                               ) -> Tuple[ActionCandidate, AuthRecord]:
        a, rec = self.select(candidates)
        if a is None:
            return fallback_action, AuthRecord(
                action=fallback_action.name, beliefs={},
                provenance_groups=[], passed=False)
        return a, rec


# 避免循环 import 的小技巧
from kg_plane.belief_graph import AssertionState as _AE
def _empty():
    return _AE(name="_empty")


if __name__ == "__main__":
    bg = BeliefGraph(lambda_f=0.9)
    bg.add_assertion("ctrl_bus5", prior=0.9)
    bg.add_assertion("path_bus5", prior=0.85)
    bg.source_reliability = {"rtu_1": 0.9}
    bg.update([Evidence("ctrl_bus5", 1.0, "rtu_1", 0, 0, 0.9),
               Evidence("path_bus5", 1.0, "rtu_1", 0, 0, 0.8)], t_now=1.0)

    verifier = ConservativeVerifier(x_hat=np.zeros(10))
    gate = RiskAwareRecoveryGate(
        bg, verifier,
        delta_q={"ctrl_bus5": 0.05, "path_bus5": 0.05},
        delta_bar_B=0.1, K_max=4)

    cands = [ActionCandidate("switch_5", ["ctrl_bus5", "path_bus5"]),
             ActionCandidate("switch_6", ["ctrl_bus5"])]
    fb = ActionCandidate("isolate", [])
    chosen, rec = gate.execute_with_fallback(cands, fb)
    print(f"Chosen: {chosen.name} | Auth passed: {rec.passed}")
    print(f"Beliefs used: {rec.beliefs}")
