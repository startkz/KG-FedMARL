# KG-FedMARL 可执行仿真环境
# IEEE 33 / 69 / 123 / 8500-Node Power-Flow & Co-Simulation

## 1. 工具链选型（对应论文实验需求）

| 层级 | 工具 | 用途 |
|---|---|---|
| Power Flow (33/69/123) | pandapower ≥2.14 | Python 原生、Newton-Raphson，可一键加载 IEEE 33/69，123 用 OpenDSS 模型导入 |
| Power Flow (8500) | GridLAB-D (HiPAS/Arras ≥4.3) 或 OpenDSS | 8500 节点原生 GLM/DSS 模型，agent-based 负载 |
| Co-Simulation 总线 | HELICS ≥3.5 | 把 GridLAB-D / OpenDSS / ns-3 / MARL 代理耦合 |
| MARL 代理 | Ray RLlib 或 MADDPG 自研 | 与 HELICS 用 Python Federate 对接 |
| KG 平面 | NetworkX + RDFLib | 构建论文 §III-B 的 \(\mathcal{G}_t^B\) |

## 2. 目录结构
```
kgfedmarl_env/
├── README.md
├── requirements.txt
├── docker-compose.yml          # 一键起 GridLAB-D + HELICS + Python
├── configs/
│   ├── ieee33.json
│   ├── ieee69.json
│   ├── ieee123.dss             # OpenDSS 123-node
│   └── ieee8500.glm            # GridLAB-D 8500-node
├── feeders/
│   ├── pandapower_33_69.py     # 33/69 一键建网 + 潮流
│   ├── opendss_123.py          # 123 节点 DSS 导入
│   └── gridlabd_8500.py        # 8500 节点 GLM 启动器
├── cosim/
│   ├── helics_broker.py        # HELICS broker + 多 federate 编排
│   ├── power_federate.py       # 潮流仿真 federate
│   ├── comm_federate.py        # ns-3 / 简化通信 federate（攻击注入点）
│   └── marl_federate.py        # MARL 决策 + KG 信念更新
├── kg_plane/
│   ├── belief_graph.py          # \(\mathcal{G}_t^B\) 实现（Algorithm 1）
│   ├── provenance.py            # 来源分组 + \(\beta_g\) 上限
│   └── recovery_gate.py         # Algorithm 2 风险门
└── scripts/
    └── run_all.sh
```

## 3. 快速开始
```bash
# 本地 Python 环境（33/69/123）
conda create -n kgfedmarl python=3.11
pip install -r requirements.txt
python feeders/pandapower_33_69.py --case ieee33  # 跑潮流

# 含 8500 + co-sim 的完整环境（推荐 Docker）
docker compose up -d
python scripts/run_all.sh
```

## 4. 与论文 Sections 的对应关系
- §III 系统模型 → feeders/*.py 生成 \(\mathcal{G}_t^p, \mathcal{G}_t^c\)
- §V-A 信念更新 → kg_plane/belief_graph.py（Algorithm 1）
- §V-B 恢复门 → kg_plane/recovery_gate.py（Algorithm 2）
- §V-C 策略自适应 → cosim/marl_federate.py（Algorithm 3）
- §VII 实验 → cosim/helics_broker.py 编排四类 feeder 场景
