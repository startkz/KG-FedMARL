#!/usr/bin/env bash
# scripts/run_all.sh
# 一键跑通 KG-FedMARL 仿真环境 (单机模式; co-sim 需先起 broker)
set -e
cd "$(dirname "$0")/.."
echo "==== 1. IEEE 33-bus 潮流 ===="
python feeders/pandapower_33_69.py --case ieee33 --out /tmp/ieee33.csv
echo
echo "==== 2. IEEE 69-bus 潮流 ===="
python feeders/pandapower_33_69.py --case ieee69 --out /tmp/ieee69.csv
echo
echo "==== 3. OpenDSS 123-node (需安装 pydss + 下载 IEEE123Master.dss) ===="
python feeders/opendss_123.py --dss configs/ieee123.dss || echo "(跳过: 缺 OpenDSS 模型)"
echo
echo "==== 4. GridLAB-D 8500-node (需 Docker 或本地 gridlabd) ===="
python feeders/gridlabd_8500.py --glm configs/ieee8500.glm --out /tmp/8500.csv || echo "(跳过: 缺 GLM 模型)"
echo
echo "==== 5. 信念图 + 恢复门 自检 ===="
python kg_plane/belief_graph.py
python kg_plane/recovery_gate.py
echo
echo "==== 6. HELICS co-sim (需先 docker compose up -d) ===="
echo "终端A: python cosim/helics_broker.py --federates 3 --duration 120"
echo "终端B: python cosim/power_federate.py --steps 60"
echo "终端C: python cosim/comm_federate.py --steps 60 --attack clean"
echo "终端D: python cosim/marl_federate.py --steps 60"
echo
echo "==== 全部完成 ===="
