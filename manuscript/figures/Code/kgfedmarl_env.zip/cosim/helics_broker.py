"""
helics_broker.py
==================
HELICS co-simulation 编排器。
启动 broker, 等待 4 个 federate 注册:
    1) power_federate   - 潮流仿真 (pandapower / GridLAB-D)
    2) comm_federate    - 通信网络 (攻击注入点)
    3) marl_federate    - MARL 决策 + KG 信念更新
    4) kg_federate      - 恢复知识图 (可选拆分)

用法:
    python helics_broker.py --federates 4 --duration 300
"""
import argparse
import time
import helics as h


def start_broker(n_federates: int, duration_s: int):
    """纯 Python broker (开发用). 生产建议用 helics_broker CLI."""
    broker = h.helicsBroker("zmq", "kgfedmarl_broker")
    broker.setPort(12345)
    broker.setFederateCount(n_federates)
    print(f"[broker] started, expecting {n_federates} federates "
          f"on port 12345")

    # 简单等待: 真实编排应轮询 broker.isConnected()
    t0 = time.time()
    while time.time() - t0 < duration_s:
        time.sleep(1)
        # 检查是否所有 federate 已注册
        if broker.getFederateCount() >= n_federates:
            print(f"[broker] all {n_federates} federates connected")
            break
    print("[broker] simulation window ended")
    broker.disconnect()
    broker = None


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--federates", type=int, default=4)
    ap.add_argument("--duration", type=int, default=300,
                    help="等待窗口 (秒)")
    args = ap.parse_args()
    start_broker(args.federates, args.duration)
