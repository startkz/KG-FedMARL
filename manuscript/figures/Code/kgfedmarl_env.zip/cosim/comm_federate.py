"""
comm_federate.py
=================
HELICS Message/Value Federate: 通信网络侧.
- 模拟网络延迟、丢包、篡改 (攻击注入点, 对应论文威胁模型 §III-C)
- 向 MARLFederate 发布 evidence JSON

攻击模式 (论文 §VII: fabrication, replay, delay, missing, correlated-source):
    - fabrication: 注入伪造报告
    - replay:      重放旧时间戳消息
    - delay:       故意推迟 delivery
    - missing:     抑制合法报告
    - correlated:  多来源共享被攻陷上游
"""
import argparse
import json
import time
import random
import helics as h


def register_federate(name: str = "CommFederate") -> h.Federate:
    fi = h.helicsFederateInfo()
    fi.coreName = "comm_core"
    fi.coreInitString = "--federates=1"
    fi.timeDelta = 1.0
    fed = h.helicsCreateValueFederate(name, fi)
    pub = fed.registerPublication("evidence", "string", "string")
    fed.enterExecutingMode()
    print(f"[comm] {name} registered")
    return fed


def generate_evidence(t: float, attack_mode: str = "clean",
                      compromised_sources: set = None) -> list:
    """生成一批证据; attack_mode 控制是否投毒."""
    ev = []
    sources = ["rtu_1", "rtu_2", "ids_1"]
    compromised_sources = compromised_sources or set()

    for src in sources:
        # missing: 抑制合法报告
        if attack_mode == "missing" and src in compromised_sources:
            continue
        # fabrication: 报告错误值
        if attack_mode == "fabrication" and src in compromised_sources:
            val = random.choice([0.0, 1.0])  # 伪造
        else:
            val = 0.9 + random.uniform(-0.05, 0.05)
        ev.append({
            "q": "ctrl_bus5" if "rtu" in src else "prot_ok",
            "value": val,
            "source": src,
            "t_event": t - random.uniform(0, 2),  # 可能延迟
            "t_recv": t,
            "conf_src": 0.8 if src not in compromised_sources else 0.99,
            "provenance_chain": (src,),
        })
    return ev


def main(steps: int = 60, attack: str = "clean",
         compromised: str = ""):
    fed = register_federate()
    comp = set(compromised.split(",")) if compromised else {"rtu_1"}
    t = 0.0
    for step in range(steps):
        while True:
            granted = fed.requestTime(t + 1.0)
            if granted >= t + 1.0:
                break
        t = granted
        ev = generate_evidence(t, attack_mode=attack,
                                compromised_sources=comp)
        payload = json.dumps({"step": int(t), "evidence": ev})
        fed.getPublication("evidence").publish(payload)
        print(f"[comm] t={t:.0f} sent {len(ev)} evidence "
              f"(attack={attack}, comp={comp})")
    fed.finalize()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=60)
    ap.add_argument("--attack", choices=["clean", "fabrication",
                                        "replay", "delay", "missing"],
                    default="clean")
    ap.add_argument("--compromised", default="rtu_1",
                    help="逗号分隔的被攻陷来源")
    args = ap.parse_args()
    main(args.steps, args.attack, args.compromised)
