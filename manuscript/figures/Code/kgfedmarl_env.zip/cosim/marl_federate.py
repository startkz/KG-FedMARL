"""
marl_federate.py
=================
HELICS Value Federate: MARL 决策 + KG 信念平面.
- 订阅 PowerFederate 的电气量 -> 本地观测 o_i,t
- 订阅 CommFederate 的测量/报告 -> 证据 z_j
- 更新 BeliefGraph (Algorithm 1)
- 过 RiskAwareRecoveryGate (Algorithm 2)
- 发布动作命令给 PowerFederate

对接论文: §IV C-Dec-POMDP, §V 三个机制
"""
import argparse
import json
import os
import sys
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from kg_plane.belief_graph import BeliefGraph, Evidence, update_reliability
from kg_plane.recovery_gate import (
    RiskAwareRecoveryGate, ActionCandidate, ConservativeVerifier
)
try:
    import helics as h
except ImportError:
    h = None  # 允许在无 HELICS 时仍跑逻辑层


def register_federate(name: str = "MARLFederate") -> h.Federate:
    fi = h.helicsFederateInfo()
    fi.coreName = "marl_core"
    fi.coreInitString = "--federates=1"
    fi.timeDelta = 1.0
    fed = h.helicsCreateValueFederate(name, fi)
    fed.registerSubscription("PowerFederate/bus_voltages", "vector")
    fed.registerSubscription("PowerFederate/line_loading", "vector")
    fed.registerSubscription("CommFederate/evidence", "string")
    pub = fed.registerPublication("switch_cmd", "string", "string")
    fed.enterExecutingMode()
    print(f"[marl] {name} registered")
    return fed


def build_kg():
    bg = BeliefGraph(lambda_f=0.9, beta_z=1.5)
    for q in ["ctrl_bus5", "path_bus5", "meas_bus12", "prot_ok"]:
        bg.add_assertion(q, prior=0.5)
    bg.set_group_budget("rtu", 2.0)
    bg.set_group_budget("ids", 1.0)
    bg.source_reliability = {"rtu_1": 0.8, "ids_1": 0.9}
    return bg


def build_gate(bg: BeliefGraph):
    verifier = ConservativeVerifier(x_hat=np.zeros(10))
    return RiskAwareRecoveryGate(
        bg, verifier,
        delta_q={"ctrl_bus5": 0.05, "path_bus5": 0.05,
                 "meas_bus12": 0.05, "prot_ok": 0.02},
        delta_bar_B=0.1, K_max=4)


def main(steps: int = 60):
    fed = register_federate()
    bg = build_kg()
    gate = build_gate(bg)
    t = 0.0

    for step in range(steps):
        while True:
            granted = fed.requestTime(t + 1.0)
            if granted >= t + 1.0:
                break
        t = granted

        # 1) 观测: 母线电压
        sub_v = fed.getSubscription("PowerFederate/bus_voltages")
        v = np.array(sub_v.getVector() or [1.0]*33, dtype=float)

        # 2) 证据: 来自通信 federate 的 JSON 报告
        sub_e = fed.getSubscription("CommFederate/evidence")
        evidences = []
        if sub_e.isUpdated():
            try:
                payload = json.loads(sub_e.getString())
                for e in payload.get("evidence", []):
                    evidences.append(Evidence(**e))
            except Exception as ex:
                print(f"[marl] evidence parse error: {ex}")

        if evidences:
            bg.update(evidences, t_now=t)

        # 3) 候选动作 (论文 §V-B)
        cands = [
            ActionCandidate("switch_5", ["ctrl_bus5", "path_bus5"]),
            ActionCandidate("shed_load_12", ["meas_bus12", "prot_ok"]),
        ]
        fb = ActionCandidate("isolate", [])
        chosen, rec = gate.execute_with_fallback(cands, fb)

        # 4) 发布动作
        cmd = {"action": chosen.name, "step": int(t)}
        fed.getPublication("switch_cmd").publish(json.dumps(cmd))
        print(f"[marl] t={t:.0f} action={chosen.name} "
              f"auth={rec.passed} b_ctrl={bg.query('ctrl_bus5'):.3f}")

    fed.finalize()
    print("[marl] done")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=60)
    args = ap.parse_args()
    main(args.steps)
