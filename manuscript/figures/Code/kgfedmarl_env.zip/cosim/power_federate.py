"""
power_federate.py
==================
HELICS Value Federate: 潮流仿真侧.
- 订阅 MARL 下发的开关动作
- 每步跑 pandapower 潮流
- 发布母线电压 / 线路负载给 MARL 与 KG

对接论文: 物理层 G_t^p, 状态转移 x_{t+1}=f(x_t,a_t,xi_t)
"""
import argparse
import time
import helics as h
import numpy as np
import pandapower as pp
from pandapower.networks import ieee33 as pp_ieee33


def register_federate(name: str = "PowerFederate") -> h.Federate:
    fi = h.helicsFederateInfo()
    fi.coreName = "power_core"
    fi.coreInitString = "--federates=1"
    fi.timeDelta = 1.0
    fi.integerProperty(h.HELICS_PROPERTY_INT_LOG_LEVEL) = h.HELICS_LOG_LEVEL_INFO
    fed = h.helicsCreateValueFederate(name, fi)
    fed.registerSubscription("MARLFederate/switch_cmd", "string")
    pub_v = fed.registerPublication("bus_voltages", "vector", "double")
    pub_l = fed.registerPublication("line_loading", "vector", "double")
    fed.enterExecutingMode()
    print(f"[power] {name} registered")
    return fed


def main(case: str = "ieee33", steps: int = 60):
    if case == "ieee33":
        net = pp_ieee33()
    else:
        raise NotImplementedError(case)

    fed = register_federate()
    t = 0.0
    for step in range(steps):
        while True:
            granted = fed.requestTime(t + 1.0)
            if granted >= t + 1.0:
                break
        t = granted

        # 1) 读取 MARL 下发的动作 (JSON 字符串: 开关状态 dict)
        sub = fed.getSubscription("MARLFederate/switch_cmd")
        msg = sub.getString() if sub.isUpdated() else "{}"
        try:
            cmd = eval(msg)  # 简化; 生产用 json.loads
        except Exception:
            cmd = {}

        # 2) 应用动作 (示例: 打开/闭合线路)
        for line_name, status in cmd.items():
            idx = net.line.index[net.line["name"] == line_name]
            if len(idx):
                net.line.at[idx[0], "in_service"] = bool(status)

        # 3) 跑潮流
        pp.runpp(net, algorithm="nr", tolerance_mva=1e-8)

        # 4) 发布电气态
        v = net.res_bus.vm_pu.values.astype(float)
        load = net.res_line.loading_percent.values.astype(float)
        fed.getPublication("bus_voltages").publish(v.tolist())
        fed.getPublication("line_loading").publish(load.tolist())
        print(f"[power] t={t:.0f} Vmin={v.min():.4f} Vmax={v.max():.4f}")

    fed.finalize()
    print("[power] done")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", default="ieee33")
    ap.add_argument("--steps", type=int, default=60)
    args = ap.parse_args()
    main(args.case, args.steps)
