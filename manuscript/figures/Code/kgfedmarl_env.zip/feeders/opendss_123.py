"""
opendss_123.py
===============
IEEE 123-node 测试馈线.

说明:
    原版 IEEE 123-node 由 OpenDSS 官方提供 (IEEE123Master.dss),
    但 `pydss-interface` 在 PyPI 上不可用 (2026-08 实测).
    本脚本用 pandapower 程序化生成一个 **123-bus 径向中压配网**,
    参数贴近 123-node 量级 (4.8 MW 总负荷, 13.2 kV), 用于算法验证.
    若需 bit-identical OpenDSS 结果, 请安装 OpenDSS 并通过
    `dss_python` 或 DSS-Extensions 加载 IEEE123Master.dss.

用法:
    python opendss_123.py --out 123_snapshot.csv
"""
import argparse
import numpy as np
import pandas as pd
import pandapower as pp


def build_123() -> pp.pandapowerNet:
    """生成 123-bus 径向网: 1 条主干(40 节点)+ 分支."""
    net = pp.create_empty_network()
    vn = 13.2
    n_bus = 123
    for i in range(n_bus):
        pp.create_bus(net, vn_kv=vn, name=f"bus_{i+1}")
    pp.create_ext_grid(net, bus=0, vm_pu=1.0, name="slack")

    rng = np.random.default_rng(123)
    r0, x0 = 0.18, 0.075
    r1, x1 = 0.22, 0.090

    # 主干 40 节点
    main_n = 40
    for i in range(main_n - 1):
        pp.create_line_from_parameters(net, from_bus=i, to_bus=i+1,
            length_km=0.6 + rng.uniform(0, 0.3),
            r_ohm_per_km=r0, x_ohm_per_km=x0,
            c_nf_per_km=0, max_i_ka=0.25,
            name=f"m_{i+1}_{i+2}")

    # 分支: 123 - 40 = 83 条短支线, 挂到主干边上
    n_leaves = n_bus - main_n
    alloc = np.zeros(main_n - 1, dtype=int)
    for _ in range(n_leaves):
        alloc[rng.integers(0, main_n - 1)] += 1
    nb = main_n
    for edge_i, n_leaf in enumerate(alloc):
        parent = edge_i + 1
        for _ in range(n_leaf):
            child = nb
            nb += 1
            pp.create_line_from_parameters(net, from_bus=parent, to_bus=child,
                length_km=0.3 + rng.uniform(0, 0.3),
                r_ohm_per_km=r1, x_ohm_per_km=x1,
                c_nf_per_km=0, max_i_ka=0.12,
                name=f"b_{parent}_{child+1}")

    # 负载 ~4.8 MW
    for i in range(1, n_bus):
        p = round(float(rng.uniform(0.015, 0.09)), 3)
        q = round(p * rng.uniform(0.35, 0.65), 3)
        pp.create_load(net, bus=i, p_mw=p, q_mvar=q, name=f"ld_{i+1}")

    pp.runpp(net, algorithm="nr", tolerance_mva=1e-8, max_iteration=80)
    return net


def summary(net: pp.pandapowerNet):
    v = net.res_bus.vm_pu.values.astype(float)
    finite = v[np.isfinite(v)]
    print(f"\n=== IEEE 123-Node (pandapower 替代) Summary ===")
    print(f"Buses: {len(net.bus)} | Lines: {len(net.line)} | Loads: {len(net.load)}")
    if len(finite):
        print(f"Vmin={finite.min():.4f} pu | Vmax={finite.max():.4f} pu")
        print(f"Violations: {int(((finite<0.95)|(finite>1.05)).sum())}")
        print(f"Total load: {net.res_bus.p_mw.sum():.3f} MW")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="123_snapshot.csv")
    args = ap.parse_args()
    net = build_123()
    summary(net)
    v = net.res_bus.vm_pu.values.astype(float)
    pd.DataFrame({
        "bus": net.bus.index + 1,
        "vm_pu": np.nan_to_num(v, nan=0.0),
        "p_mw": net.res_bus.p_mw.values,
        "q_mvar": net.res_bus.q_mvar.values,
    }).to_csv(args.out, index=False)
    print(f"[123] Snapshot -> {args.out}")


if __name__ == "__main__":
    main()
