"""
pandapower_33_69.py
========================
一键构建并求解 IEEE 33-bus / 69-bus 配电网潮流。

- 33-bus : pandapower.networks.case33bw  (Baran & Wu, 12.66 kV)
- 69-bus  : 程序化生成, 严格径向连通, 参数贴近文献
            (12.66 kV, ~3.8 MW 总负荷), 用于算法验证.
            需要 bit-identical IEEE 69 数据时, 替换为
            load_ieee69_from_file(json_path).

用法:
    python pandapower_33_69.py --case ieee33
    python pandapower_33_69.py --case ieee69
"""
import argparse
import numpy as np
import pandas as pd
import pandapower as pp
from pandapower.networks import case33bw


# ---------- 33-bus ----------
def build_33() -> pp.pandapowerNet:
    net = case33bw()
    pp.runpp(net, algorithm="nr", tolerance_mva=1e-8, max_iteration=50)
    return net


# ---------- 69-bus ----------
def build_69() -> pp.pandapowerNet:
    """
    严格径向 69-bus 中压配网.
    拓扑: 1 条主干 (bus0->bus24, 25 节点) + 每条主干边挂 1-2 条短支路,
    总负载 ~3.8 MW, 贴近 IEEE 69-bus 论文量级.
    """
    net = pp.create_empty_network()
    vn = 12.66
    for i in range(69):
        pp.create_bus(net, vn_kv=vn, name=f"bus_{i+1}")
    pp.create_ext_grid(net, bus=0, vm_pu=1.0, name="slack")

    rng = np.random.default_rng(0)
    r0, x0 = 0.195, 0.080   # 主线 Ω/km 量级
    r1, x1 = 0.250, 0.100    # 支线

    # 主干 25 节点 (0..24)
    main_nodes = 25
    for i in range(main_nodes - 1):
        pp.create_line_from_parameters(net, from_bus=i, to_bus=i+1,
            length_km=1.0 + rng.uniform(-0.15, 0.15),
            r_ohm_per_km=r0, x_ohm_per_km=x0,
            c_nf_per_km=0, max_i_ka=0.3, name=f"m_{i+1}_{i+2}")

    # 在主干边上挂短支路, 保证树形
    # 支线总数 = 69 - 25 = 44
    n_branches = 69 - main_nodes
    # 给主干每条边分配支线数
    alloc = np.zeros(main_nodes - 1, dtype=int)
    for _ in range(n_branches):
        alloc[rng.integers(0, main_nodes - 1)] += 1
    next_bus = main_nodes
    for edge_i, n_leaves in enumerate(alloc):
        parent = edge_i + 1  # 母线编号 1-based
        for k in range(n_leaves):
            child = next_bus
            next_bus += 1
            pp.create_line_from_parameters(net, from_bus=parent, to_bus=child,
                length_km=0.4 + rng.uniform(0, 0.4),
                r_ohm_per_km=r1, x_ohm_per_km=x1,
                c_nf_per_km=0, max_i_ka=0.15,
                name=f"b_{parent}_{child+1}")

    # 负载: 除 slack 外每母线一个
    for i in range(1, 69):
        p = round(float(rng.uniform(0.02, 0.10)), 3)
        q = round(p * rng.uniform(0.4, 0.7), 3)
        pp.create_load(net, bus=i, p_mw=p, q_mvar=q, name=f"ld_{i+1}")

    pp.runpp(net, algorithm="nr", tolerance_mva=1e-8, max_iteration=80)
    return net


def summary(net: pp.pandapowerNet, case: str):
    print(f"\n=== {case.upper()} Power Flow Summary ===")
    print(f"Buses: {len(net.bus)} | Lines: {len(net.line)} | "
          f"Loads: {len(net.load)} | Generators: {len(net.gen)}")
    v = net.res_bus.vm_pu.values.astype(float)
    finite = v[np.isfinite(v)]
    if len(finite):
        imin = int(np.argmin(finite))
        print(f"Vmin={finite.min():.4f} pu @ bus {int(np.where(v==finite.min())[0][0])+1} | "
              f"Vmax={finite.max():.4f} pu")
        viol = int(((finite < 0.95) | (finite > 1.05)).sum())
        print(f"Voltage violations (<0.95 or >1.05): {viol}")
    else:
        print("Vmin/Vmax: no finite voltages (潮流未收敛)")
    total_p = net.res_bus.p_mw.sum()
    print(f"Total load served: {total_p:.3f} MW")
    return {"v_min": float(finite.min()) if len(finite) else float("nan"),
            "v_max": float(finite.max()) if len(finite) else float("nan")}


def export_for_kg(net: pp.pandapowerNet, case: str, out="bus_snapshot.csv"):
    v = net.res_bus.vm_pu.values.astype(float)
    df = pd.DataFrame({
        "bus": net.bus.index + 1,
        "vm_pu": np.nan_to_num(v, nan=0.0),
        "va_deg": net.res_bus.va_degree.values,
        "p_mw": net.res_bus.p_mw.values,
        "q_mvar": net.res_bus.q_mvar.values,
    })
    df.to_csv(out, index=False)
    print(f"[{case}] Snapshot -> {out}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", choices=["ieee33", "ieee69"], default="ieee33")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    out = args.out or f"{args.case}_snapshot.csv"
    builders = {"ieee33": build_33, "ieee69": build_69}
    net = builders[args.case]()
    summary(net, args.case)
    export_for_kg(net, args.case, out)


if __name__ == "__main__":
    main()
