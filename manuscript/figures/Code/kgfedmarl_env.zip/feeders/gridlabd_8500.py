"""
gridlabd_8500.py
=================
启动 GridLAB-D (HiPAS/Arras) 跑 IEEE 8500-node 测试馈线，
并解析其 JSON/CSV 输出为 KG-FedMARL 可用的快照。

8500 节点模型来源:
    https://cmte.ieee.org/pes-testfeeders/  (8500-Node Test Feeder)
    GridAPPS-D 已导出 CIM/GLM 版本可直接用。

运行:
    python gridlabd_8500.py --glm configs/ieee8500.glm --out 8500_snapshot.csv
"""
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path
import pandas as pd
import numpy as np


def run_gridlabd(glm_path: str, workdir: str = "."):
    """调用 gridlabd 二进制。Docker 内为 `gridlabd`, 本地需自行安装 HiPAS。"""
    cmd = ["gridlabd", str(glm_path)]
    print(f"[8500] Exec: {' '.join(cmd)}")
    res = subprocess.run(cmd, cwd=workdir, capture_output=True, text=True)
    if res.returncode != 0:
        print("STDERR:", res.stderr[-500:])
        raise RuntimeError("GridLAB-D 运行失败")
    print("[8500] GridLAB-D 完成")


def parse_outputs(workdir: str, out_csv: str):
    """读取 GridLAB-D 生成的 *_metrics.json 或 recorder CSV, 输出统一快照。"""
    wd = Path(workdir)
    jsons = list(wd.glob("*_metrics.json")) + list(wd.glob("*.json"))
    rows = []
    for jf in jsons:
        try:
            data = json.loads(jf.read_text())
        except Exception:
            continue
        # GridLAB-D 输出结构各异, 这里做宽容提取
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, (int, float)):
                    rows.append({"bus": k, "value": v})
    if not rows:
        # fallback: 解析 recorder CSV
        for cf in wd.glob("*.csv"):
            df = pd.read_csv(cf)
            if "voltage" in df.columns or "V" in df.columns:
                col = "voltage" if "voltage" in df.columns else "V"
                rows = [{"bus": i, "vm_pu": float(v)/120.0}
                        for i, v in enumerate(df[col])]
                break
    df = pd.DataFrame(rows)
    df.to_csv(out_csv, index=False)
    print(f"[8500] Snapshot -> {out_csv}  ({len(df)} rows)")
    if "vm_pu" in df.columns:
        v = df["vm_pu"].dropna().values
        if len(v):
            print(f"[8500] Vmin={v.min():.4f} | Vmax={v.max():.4f} | "
                  f"violations={(v<0.95).sum()+(v>1.05).sum()}")
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--glm", default="configs/ieee8500.glm")
    ap.add_argument("--workdir", default=".")
    ap.add_argument("--out", default="8500_snapshot.csv")
    args = ap.parse_args()
    if not Path(args.glm).exists():
        print(f"缺少 {args.glm}; 请从 IEEE PES / GridAPPS-D 下载 8500-node GLM")
        sys.exit(1)
    run_gridlabd(args.glm, args.workdir)
    parse_outputs(args.workdir, args.out)
